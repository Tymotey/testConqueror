<h1 id="page_title">Order Summary</h1>

<div id="checkout_list"></div>
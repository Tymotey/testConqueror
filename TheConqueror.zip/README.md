# Deploy:

-   clone GIT from link [https://github.com/Tymotey/testConqueror](https://github.com/Tymotey/testConqueror)
-   create database. Compatible collation: utf8mb4_general_ci
-   import database from file: **sql/db.zip** to newly created database. Example data will be imported too.
-   change access to database in file **config.php**, variables: DB_NAME, DB_USER, DB_PASSWORD, DB_HOST
-   apache access(user and pass): theconqueror

-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table theconqueror.items
DROP TABLE IF EXISTS `items`;
CREATE TABLE IF NOT EXISTS `items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `popularity` int NOT NULL DEFAULT '0',
  `route_length` int NOT NULL DEFAULT '0',
  `postcards` int NOT NULL DEFAULT '0',
  `street_view` tinyint(1) NOT NULL DEFAULT '0',
  `image` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `back_image` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `added_on` datetime DEFAULT CURRENT_TIMESTAMP,
  `price` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table theconqueror.items: ~7 rows (approximately)
DELETE FROM `items`;
INSERT INTO `items` (`id`, `name`, `enabled`, `popularity`, `route_length`, `postcards`, `street_view`, `image`, `back_image`, `added_on`, `price`) VALUES
	(1, 'Mount Kilimanjaro', 1, 4, 97, 5, 0, '21.png', 'bkg_21.png', '2023-12-17 18:03:47', 75),
	(2, 'Angkor Wat', 1, 1, 32, 4, 1, 'AW.png', 'bkg_aw.png', '2023-10-17 18:03:47', 25),
	(3, 'Inca Trail', 0, 1, 42, 4, 1, 'IT.png', 'bkg_it.png', '2023-10-17 18:03:47', 150),
	(4, 'Berlin Wall', 1, 2, 48, 5, 1, '39.png', 'bkg_39.png', '2023-10-17 18:03:47', 50),
	(5, 'Flower Route', 1, 33, 66, 0, 1, 'FLR.png', 'bkg_flr.png', '2023-10-17 18:03:47', 125),
	(6, 'Transylvania', 1, 3, 372, 7, 1, 'transylvania.png', 'bkg_54.png', '2023-10-17 18:03:47', 100),
	(7, 'Alps to Ocean', 1, 20, 290, 9, 0, '06.png', 'bkg_06_alps.png', '2023-12-17 19:06:30', 100);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
